import { FiltroEmpleadosPipe } from './filtro-empleados.pipe';

describe('FiltroEmpleadosPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltroEmpleadosPipe();
    expect(pipe).toBeTruthy();
  });
});
