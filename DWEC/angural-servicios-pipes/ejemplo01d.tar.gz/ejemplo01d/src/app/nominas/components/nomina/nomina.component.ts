import { Component } from '@angular/core';
import { Nomina } from '../../nominas';
@Component({
  selector: 'app-nominas-nomina',
  templateUrl: './nomina.component.html',
  styleUrl: './nomina.component.css',
})
export class NominaComponent {
  
}
