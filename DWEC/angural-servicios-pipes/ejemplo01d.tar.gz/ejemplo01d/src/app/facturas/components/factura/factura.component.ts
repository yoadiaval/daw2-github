import { Component } from '@angular/core';
import { Factura } from '../../factura';

@Component({
  selector: 'app-facturas-factura',
  templateUrl: './factura.component.html',
  styleUrl: './factura.component.css',
})
export class FacturaComponent {
 
}
