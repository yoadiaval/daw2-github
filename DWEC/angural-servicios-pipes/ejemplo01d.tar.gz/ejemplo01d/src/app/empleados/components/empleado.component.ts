import { Component, ViewChild } from '@angular/core';
import { Empleado } from '../empleado';
import { ListaComponent } from './lista.component';

@Component({
  selector: 'app-empleados-empleado',
  standalone: false,
  templateUrl: './empleado.component.html',
  styleUrl: './empleado.component.css',
})
export class EmpleadoComponent {
  
 
}
