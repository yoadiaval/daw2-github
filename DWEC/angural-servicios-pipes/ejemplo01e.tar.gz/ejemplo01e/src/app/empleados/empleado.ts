export class Empleado {
  constructor(
    public id: number,
    public nombre: string,
    public edad: number,
    public contratado: boolean = false
  ) {}
  
}
