# videoClub-project Respuestas a preguntas teóricas

## ¿Qué conseguimos al hacer la clase soporte abstracta? 
Conseguimos que no se puedan crear instancias de la clase Soporte. Pero sí se valdría como base 
para las clases hijas. Con lo cual podría usar el Polimorfismo, o sea podría crear un arreglo de objetos de tipo Soporte, que sería un tipo genérico, donde cada uno de los elementos del array pueden  ser en realidad de tipo de las clases hijas de Soporte. También permite que declaremos métodos abstractos dentro de ella, que van a variar su implementación en dependencia de la clase hija que lo implemente. 

## ¿Hace falta que también se implemente en los hijos la interfaz resumible?
Los hijos no tienen que implementar la interfaz resumible, con que la implemente el padre es suficiente.
