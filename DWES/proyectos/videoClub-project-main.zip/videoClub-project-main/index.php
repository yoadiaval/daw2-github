<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Login</title>
    <link rel="stylesheet" href="./style/style.css">
</head>

<body>
    <h1>Videoclub 3.0</h1>
    <div class="login-container">
        <h2>Iniciar sesión</h2>
        <form action="./app/controlSesiones/login.php" method="POST">
            <input type="text" name="usuario" placeholder="Usuario" class="input-field">
            <input type="password" name="password" placeholder="contraseña" class="input-field">

            <div class="checkbox-container">
                <input type="checkbox" name="administrador" id="administrador">
                <label for="administrador" class="checkbox-label">Administrador</label>
            </div>
            <button type="submit" class="btn-login" name="enviar">Iniciar sesión</button>
        </form>

    </div>

</body>

</html>