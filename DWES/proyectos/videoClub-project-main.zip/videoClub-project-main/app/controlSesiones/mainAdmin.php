<?php
include_once "../../autoload.php";
use Dwes\ProyectoVideoclub\Videoclub;

// Recuperamos la información de la sesión
if (!isset($_SESSION)) { //se ejecutra si la variable $_SESSION no está definida o iniciada 
    session_start(); //inicia sesion en el servidor



    /*header("Location: ./cargarDatos.php");*/
}

// Y comprobamos que el usuario se haya autentificado
if (!isset($_SESSION['usuario'])) { //vefifica que haya un usuario logueado
    die("Error - debe <a href='index.php'>identificarse</a>.<br />");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../style.css">
    <title>Document</title>
</head>

<body>
    <h1>Bienvenido <?= $_SESSION['usuario'] ?></h1>
    <h2>Listado productos disponibles</h2>
    <table>
        <thead>
            <td>Título</td>
            <td>Número</td>
            <td>Precio</td>
        </thead>
        <tbody>
            <?php
            $listProductos = $_SESSION['videoClub']->getProductos();
            foreach ($listProductos as $producto) {
                echo "<tr><td>" . $producto->getTitulo() . "</td><td>" . $producto->getNumero() . "</td><td>" . $producto->getPrecio() . "</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <h2>Listado clientes activos</h2>
    <table>
        <thead>
            <td>Nombre</td>
            <td>Número</td>
            <td>Usuario</td>
            <td>Número de soportes alquilados</td>
        </thead>
        <tbody>
            <?php
            $listadoClientes = $_SESSION['videoClub']->getSocios();
            foreach ($listadoClientes as $cliente) {
                echo "<tr>
                        <td>" . $cliente->getNombre() . "</td>
                        <td>" . $cliente->getNumero() . "</td>
                        <td>" . $cliente->getUsuario() . "</td>
                        <td>" . $cliente->getNumSoportesAlquilados() . "</td>
                     <tr>";
            }
            ?>
        </tbody>
    </table>


    <p>Pulse <a href="./logout.php">aquí</a> para salir</p>

</body>

</html>