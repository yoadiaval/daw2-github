<?php
include_once "../../autoload.php";
use Dwes\ProyectoVideoclub\Videoclub;

// Creamos una instancia del Videoclub
$vc = new Videoclub("Severo 8A");

// Incluir soportes
$vc->incluirCintaVideo("Los cazafantasmas", 3.5, 103);
$vc->incluirDvd("Origen", 2, "es,en", "16:9");
$vc->incluirJuego("The Last of Us Part II", 49.99, "PS4", 1, 1);

// Incluir socios
$vc->incluirSocio("Amancio Ortega", "amancio", "amancio");
$vc->incluirSocio("Pedro Vargas", "pedro", "pedro");

// Alquilar soportes a socios
$vc->alquilarSocioProducto(1, 1);
$vc->alquilarSocioProducto(1, 2);

// Al final, retornamos la instancia de $vc
$arrayAsociativoClientes = [];

foreach ($vc->getSocios() as $socio) {
    $arrayAsociativoClientes[$socio->getUsuario()] = $socio;
}


?>