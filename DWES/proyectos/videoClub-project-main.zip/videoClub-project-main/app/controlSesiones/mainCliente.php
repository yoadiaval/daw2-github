<?php
include_once "../../autoload.php";
use Dwes\ProyectoVideoclub\Cliente;
// Recuperamos la información de la sesión
if (!isset($_SESSION)) { //se ejecutra si la variable $_SESSION no está definida o iniciada 
    session_start(); //inicia sesion en el servidor
}

// Y comprobamos que el usuario se haya autentificado
if (!isset($_SESSION['usuario'])) { //vefifica que haya un usuario logueado
    die("Error - debe <a href='index.php'>identificarse</a>.<br />");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../style.css">
    <title>Document</title>
</head>

<body>
    <h1>Bienvenido <?= $_SESSION['usuario'] ?></h1>
    <h2>Listado de productos alquilados</h2>
    <table class="table">
        <thead>
            <td>Título</td>
            <td>Número</td>
            <td>Precio</td>
        </thead>
        <tbody>
            <?php
            $listProductosAlquilados = $_SESSION['usuarioObj']->getAlquileres();
            foreach ($listProductosAlquilados as $producto) {
                echo "<tr><td>" . $producto->getTitulo() . "</td><td>" . $producto->getNumero() . "</td><td>" . $producto->getPrecio() . "</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <p>Pulse <a href="./logout.php">aquí</a> para salir</p>

</body>

</html>