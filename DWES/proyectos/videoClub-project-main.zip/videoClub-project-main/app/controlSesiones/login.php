<?php
$contenido = file_get_contents('cargarDatos.php');  // Carga el contenido del archivo
eval('?>' . $contenido);  //ejecuto el contenido del archivo 

//almsceno en variables:
$clientes = $arrayAsociativoClientes; //listado de clientes. 
$videoClub = $vc; //Instancia completa de videoClub.

// Comprobamos si se ha enviado el formulario
if (isset($_POST['enviar'])) {
    // Recuperamos los valores de los campos del formulario usando $_POST
    $usuario = $_POST["usuario"];  // nombre del campo en el formulario
    $password = $_POST["password"];   // nombre del campo en el formulario
    
    
    $usuarioObj = $clientes[$usuario]; 
    
    // Validamos que se hayan recibido ambos parámetros
    if (empty($usuario) || empty($password)) {
        $error = "Debes introducir un usuario y una contraseña"; // Mensaje de error

        header("Location: ../../index.php"); // Volver a cargar la página de login (index.php) haciendo una redireccion 
        //si hubiera utilizado include no se cargarían correctamente los estilos
    } else {
        // Comprobamos si las credenciales son correctas
        if ($usuario == "admin" && $password == "admin") {
            // Si son correctas, iniciamos la sesión y almacenamos el usuario
            session_start();
            $_SESSION['usuario'] = $usuario;
            $_SESSION['videoClub'] = $videoClub;

            // Redirigimos a la página principal
            header("Location: ./mainAdmin.php");
            exit(); // Importante para asegurarnos de que el código posterior no se ejecute
        } else if ($usuarioObj !== null && $usuarioObj->verificarPassword($password)) {

            session_start();
            //en la variable de sesion almaceno el objeto completo
            $_SESSION['usuario'] = $usuario;
            $_SESSION['usuarioObj'] = $usuarioObj;

            // Redirigimos a la página principal
            header("Location: ./mainCliente.php");
            exit(); // Importante para asegurarnos de que el código posterior no se ejecute
        } else {
            // Si las credenciales no son válidas, mostramos el mensaje de error y volvemos al login
            $error = "Usuario o contraseña no válidos!";
            header("Location: ../../index.php"); // Volver a cargar el login
        }
    }
}

?>