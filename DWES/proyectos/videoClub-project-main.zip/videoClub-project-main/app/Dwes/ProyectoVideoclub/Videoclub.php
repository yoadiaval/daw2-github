<?php
namespace Dwes\ProyectoVideoclub;
use Dwes\ProyectoVideoclub\Util\SoporteYaAlquiladoExcepcion;
use Dwes\ProyectoVideoclub\Util\VideoclubException;
use Dwes\ProyectoVideoclub\Util\CupoSuperadoException;
use Dwes\ProyectoVideoclub\Util\ClienteNoEncontradoException;

include_once "Dvd.php";
include_once "Juego.php";
include_once "Cliente.php";
include_once "CintaVideo.php";

use Dwes\ProyectoVideoclub\Dvd;
use Dwes\ProyectoVideoclub\Juego;
use Dwes\ProyectoVideoclub\Cliente;
use Dwes\ProyectoVideoclub\CintaVideo;

class Videoclub
{
    private $nombre;
    private $productos = [];
    private $numProductos;
    private $socios = [];
    private $numSocios;
    private $numProductosAlquilados;
    private $numTotalAlquileres;


    public function __construct($nombre)
    {
        $this->nombre = $nombre;
        $this->productos = null;
        $this->numProductos = 0;
        $this->socios = null;
        $this->numSocios = 0;
    }


    public function getNumProductosAlquilados()
    {
        echo "<p> Actualmente hay " . $this->numProductosAlquilados . " productos alquilados</p>";
    }

    public function getNumTotalAlquileres()
    {
        echo "<p> Hasta el momento se han realizado " . $this->numTotalAlquileres . " alquileres</p>";
    }

    public function getProductos()
    {
        return $this->productos;
    }

    public function getSocios()
    {
        return $this->socios;
    }
    //***********TRABAJO CON SOPORTES(PRODUCTOS)******************
    private function incluirProducto(Soporte $producto)
    {
        $this->productos[] = $producto;   //agregar productos de tipo Soporte al array (usando Polimorfismo)
        $this->numProductos++;
        /*echo "<br> Incluido soporte " . $producto->getNumero();*/
    }

    //AGREGAR UNA CINTA DE VIDEO
    public function incluirCintaVideo($titulo, $precio, $duracion)
    {
        $nuevaCinta = new CintaVideo($titulo, $precio, $duracion);
        $this->incluirProducto($nuevaCinta); //agregar elemento al array
    }


    //AGREGAR UN DVD
    public function incluirDvd($titulo, $precio, $idiomas, $pantalla)
    {

        $nuevoDvd = new Dvd($titulo, $precio, $idiomas, $pantalla);
        $this->incluirProducto($nuevoDvd); //agregar elemento al array

    }

    public function incluirJuego($titulo, $precio, $consola, $minJ, $maxJ)
    {

        $nuevoJuego = new Juego($titulo, $precio, $consola, $minJ, $maxJ);
        $this->incluirProducto($nuevoJuego); //agregar elemento al array

    }

    public function listarProductos()
    {
        echo "<br><br><br>Listado de los " . $this->numProductos . " productos disponibles:<br>";

        $contador = 1;

        foreach ($this->productos as $prod) {
            echo "<br>" . $contador . ".-";
            echo $prod->muestraResumen();
            $contador++;
        }
    }

    //***************TRABAJO CON SOCIOS*****************************
    public function incluirSocio($nombre, $usuario, $password, $maxAlquileresRecurrentes = 3)
    {
        $clienteNuevo = new Cliente($nombre, $usuario, $password, $maxAlquilerConcurrente = 3);
        $this->socios[] = $clienteNuevo;
        $this->numSocios++;
        /* echo "<br> Incluido socio " . $clienteNuevo->getNumero();*/
        return $this;
    }

    public function listarSocios()
    {
        echo "<br><br>Listado de " . $this->numSocios . " socios del videoclub:<br>";

        $contador = 1;

        foreach ($this->socios as $socio) {
            echo "<br>" . $contador . ".-";
            echo $socio->muestraResumen();
            $contador++;
        }
    }

    public function alquilarSocioProducto($numeroCliente, $numeroSoporte)
    {
        $soporteAlquila = null; //soporte a alquilar
        $clienteAlquila = null;

        //busco el soporte a alquilar
        if (empty($this->productos)) {
            echo "No hay soportes";
        } else {
            for ($i = 0; $i < count($this->productos); $i++) {
                if ($this->productos[$i]->getNumero() === $numeroSoporte) {
                    $soporteAlquila = $this->productos[$i];
                    break;
                }
            }

        }

        //buscar el cliente que va a alquilar el soporte
        $existClient = false;
        if (empty($this->socios)) {
            echo "No hay socios almacenados";
        } else {
            for ($i = 0; $i < count($this->socios); $i++) {
                if ($this->socios[$i]->getNumero() === $numeroCliente) {
                    $clienteAlquila = $this->socios[$i];
                    $existClient = true;
                    break;
                }
            }
            try {
                if (!$existClient) {
                    throw new ClienteNoEncontradoException("Socio no encontrado en la lista");
                }
            } catch (ClienteNoEncontradoException $e) {
                echo "<br/>" . $e->getMessage() . "<br/>";
            }
        }

        //alquilar producto

        if ((!is_null($soporteAlquila)) && (!is_null($clienteAlquila))) {
            echo "<br>";

            try {
                $alquilerRealizado = $clienteAlquila->alquilar($soporteAlquila);
                if ($alquilerRealizado !== false) // si se pudo realizar el alquiler
                {
                    $this->numProductosAlquilados++; //cantidad de productos que hay alquilados en ese momento en el videoClub
                    $this->numTotalAlquileres++; //cantidad total de alquileres que se han realizado en el videoclub
                }

            } catch (SoporteYaAlquiladoExcepcion $e) {
                echo $e->getMessage() . "\n";
            } catch (CupoSuperadoException $e) {
                echo $e->getMessage() . "\n";
            } catch (VideoclubException $e) {
                echo $e->getMessage() . "\n";
            }
        } else {
            echo "<br/>Número de cliente o número de Producto incorrecto<br/>";
        }
        return $this;
    }





    /********************MÉTODOS VERSION 2.0******************/



    //METODO PARA COMPROBRAR SI SE PUEDE ALQUILAR UN LOTE DE PRODUCTOS, SI SE PUEDE LOS ALQUILA
    public function alquilarSocioProductos($numSocio, $numerosProductos)
    {
        $puedeAlquilarlos = true;

        //compruebo si alguno de los productos del lote a alquilar ya está alquilado 
        for ($i = 0; $i < count($numerosProductos); $i++) {
            for ($j = 0; $j < count($this->productos); $j++) {
                if ($this->productos[$j]->getNumero() === $numerosProductos[$i]) //busco el producto en el array de productos
                {
                    if ($this->productos[$j]->alquilado === true) {
                        $puedeAlquilarlos = false;
                        echo "<br/>No se puede alquilar el lote porque incluye productos no disponibles<br/>";
                        break 2; //me sale de los dos bucles
                    }
                }
            }

        }

        //si ninguno de los productos del lote está alquilado alquilo el lote completo
        if ($puedeAlquilarlos === true) {
            for ($i = 0; $i < count($numerosProductos); $i++) {
                $this->alquilarSocioProducto($numSocio, $numerosProductos[$i]);
            }
        }

        return $this;

    }


    //El socio devuelve el Producto y este pasa a estar disponible para ser alquilado de nuevo
    public function devolverSocioProducto($numSocio, $numeroProducto)
    {
        $puedeDevolver = false;

        //comprueba que el producto está alquilado
        for ($i = 0; $i < count($this->productos); $i++) {
            if ($this->productos[$i]->alquilado === true) {
                $puedeDevolver = true;
            } else if (($this->productos[$i]->alquilado === false) && ($this->productos[$i]->getNumero() === $numeroProducto)) {
                echo "<p>El producto " . $this->productos[$i]->getNumero() . " no se puede devolver porque no está alquilado</p>";
            }
        }

        //devuelve el producto
        if ($puedeDevolver) {
            for ($j = 0; $j < count($this->socios); $j++) {
                if (($this->socios[$j]->getNumero() === $numSocio)) {

                    $devolucionRealizada = $this->socios[$j]->devolver($numeroProducto);  //almacena $this o false

                    if ($devolucionRealizada !== false) // si se pudo realizar la devolución
                    {
                        $this->numProductosAlquilados--; //control de productos alquilados en ese momento en el videoclub               
                    }
                    break;
                }
            }
        }

        return $this; //permite el encadenamiento de métodos
    }

    //El socio devuelve un lote de varios Productos y estos pasan a estar disponibles para ser alquilados de nuevo
    function devolverSocioProductos($numSocio, $numerosProductos)
    {

        for ($i = 0; $i < count($this->socios); $i++) {
            if ($this->socios[$i]->getNumero() === $numSocio) {
                for ($j = 0; $j < count($numerosProductos); $j++) {
                    $this->devolverSocioProducto($numSocio, $numerosProductos[$j]);
                }
            }

        }

        return $this;
    }



}
