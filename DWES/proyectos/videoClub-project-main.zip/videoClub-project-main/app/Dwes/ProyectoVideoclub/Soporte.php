<?php
namespace Dwes\ProyectoVideoclub;
include_once "InterfazResumible.php";
use Dwes\ProyectoVideoclub\resumible;

abstract class Soporte implements resumible
{
    public $titulo;
    protected $numero;
    private $precio;
    private const IVA = 0.21; //las constantestes de clase declaradas con const son static por defecto
    private static $numSoporte = -1;
    public $alquilado=false;

    public function __construct($titulo, $precio)
    {
        $this->titulo = $titulo;
        // Soporte::$numero= Soporte::$numero+1;
        $this->numero = Soporte::$numSoporte + 1;
        Soporte::$numSoporte = $this->numero;
        $this->precio = $precio;
    }
    public function getTitulo(){
        return $this->titulo;
    }
    public function getPrecio()
    {
        return $this->precio;
    }
    public function getPrecioConIva()
    {
        $precioConIva = (self::IVA * $this->precio) + $this->precio;
        return $precioConIva;
    }
    public function getNumero()
    {
        return $this->numero;
    }
    public function muestraResumenComun()
    {
        echo "<br> <i>" . $this->titulo . "</i> <br/>" . $this->precio . " &euro; (IVA no incluido)";
    }

    //SE QUITA EL MÉTODO ABSTRACTO muestraresumen() YA QUE AL IMPLEMENTAR LA INTERFAZ ESTA GARANTIZA QUE LAS SUBCLASES IMPLEMENTEN ESTE MÉTODO.
    //DESDE LA CLASE SOPORTE NO SE PUEDEN CREAR INSTANCIAS LUEGO NO ESTA OBLIGADA A IMPLEMENTAR EL METODO DEFINIDO EN LA INTERFAZ PERO DE NO HACERLO 
    //SE DEBE DE HACER EN LAS HIJAS.
}
?>