<?php
namespace Dwes\ProyectoVideoclub;
include_once "Soporte.php";
use Dwes\ProyectoVideoclub\Soporte;

class Dvd extends Soporte
{
    public $idioma;
    private $formatPantalla;
    public function __construct($titulo, $precio, $idioma, $format)
    {
        parent::__construct($titulo, $precio);
        $this->idioma = $idioma;
        $this->formatPantalla = $format;
    }
    public function muestraResumen()
    {
        echo "Película en DVD:";
        parent::muestraResumenComun();
        echo "<br>Idiomas: " . $this->idioma . "<br> Formato Pantalla: " . $this->formatPantalla . "<br>";
    }
}
?>