<?php
namespace Dwes\ProyectoVideoclub;

interface resumible
{
    public function muestraResumen();
}

?>