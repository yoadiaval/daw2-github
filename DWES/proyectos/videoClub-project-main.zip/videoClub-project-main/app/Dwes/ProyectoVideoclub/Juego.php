<?php
namespace Dwes\ProyectoVideoclub;
include_once "Soporte.php";

use Dwes\ProyectoVideoclub\Soporte;
class Juego extends Soporte
{

    public $consola;
    private $minNumJugadores;
    private $maxNumJugadores;


    public function __construct($titulo, $precio, $consola, $minNumJugadores, $maxNumJugadores)
    {
        parent::__construct($titulo, $precio);
        $this->consola = $consola;
        $this->minNumJugadores = $minNumJugadores;
        $this->maxNumJugadores = $maxNumJugadores;
    }

    public function muestraJugadoresPosibles()
    {

        if (is_numeric($this->minNumJugadores) && is_numeric($this->maxNumJugadores) && $this->minNumJugadores > 0) {
            if ($this->maxNumJugadores === 1) {
                echo "<br> Para un jugador";
            } elseif (($this->minNumJugadores === $this->maxNumJugadores) && ($this->maxNumJugadores !== 1)) {
                echo "Para " . $this->minNumJugadores . " jugadores";
            } else {
                echo "De" . $this->minNumJugadores . " a " . $this->maxNumJugadores;
            }
        } else {
            echo "Número de jugadores no indicado";   //esto lo he agregado
        }
    }

    public function muestraResumen()
    {
        echo "Juego para: " . $this->consola;
        /*echo "<br>".$this->titulo;
        echo "<br>".$this->getPrecio()." &euro; (IVA no incluido)";*/
        parent::muestraResumenComun();
        echo "<br><i>" . $this->muestraJugadoresPosibles() . "</i>";

    }


}

?>