<?php
namespace Dwes\ProyectoVideoclub;
use Dwes\ProyectoVideoclub\Util\SoporteYaAlquiladoExcepcion;
use Dwes\ProyectoVideoclub\Util\SoporteNoEncontradoException;
use Dwes\ProyectoVideoclub\Util\CupoSuperadoException;
class Cliente
{
    public $nombre;
    private $usuario;
    private $password;
    private $numero;
    private static $numCliente = -1;
    private $soportesAlquilados = [];
    private $numSoportesAlquilados = 0;
    private $maxAlquilerConcurrente;


    public function __construct($nombre, $usuario, $password, $maxAlquilerConcurrente = 3, )
    {
        $this->nombre = $nombre;
        $this->usuario = $usuario;
        // Guardamos la contraseña como un hash para mayor seguridad
        $this->password = password_hash($password, PASSWORD_DEFAULT);
        $this->maxAlquilerConcurrente = $maxAlquilerConcurrente;
        $this->numero = Cliente::$numCliente + 1;
        Cliente::$numCliente = $this->numero;

    }

    //DEFINICIÓN DE GETTERS Y SETTERS
    public function getNombre()
    {
        return $this->nombre;
    }
    public function getNumero()
    {
        return $this->numero;
    }
    public function getAlquileres()
    {
        return $this->soportesAlquilados;
    }
    public function setNumero($nuevoValor)
    {
        $this->numero = $nuevoValor;
        //Cliente::$numero=$nuevoValor;
    }

    public function getNumSoportesAlquilados()
    {
        return $this->numSoportesAlquilados;
    }

    public function muestraResumen()
    {
        echo "Nombre: " . $this->nombre . "<br/>" . "Cantidad de alquileres: " . count($this->soportesAlquilados) . "<br>";
    }

    public function getUsuario()
    {
        return $this->usuario;
    }

    //VERIFICA SI LA CONTRASEÑA PROPORCIONADA COINCIDE
    public function verificarPassword($password)
    {
        return password_verify($password, $this->password);
    }

    //RESTO DE FUNCIONES 
    public function tieneAlquilado($numero)
    {
        $alquilado = false;
        foreach ($this->soportesAlquilados as $item) {
            if ($item->getNumero() == $numero) {
                $alquilado = true;
            }
        }
        return $alquilado;
    }

    public function alquilar($soporte)
    {
        $alquilerRealizado = false;
        //VERIFICA QUE EL SOPORTE NO ESTÉ ALQUILADO.
        $existe = self::tieneAlquilado($soporte->getNumero());

        if ($existe) {
            throw new SoporteYaAlquiladoExcepcion("Ya el soporte está alquilado");
        }

        if (!$existe and $this->numSoportesAlquilados < 3) {
            //SI NO EXISTE Y AUN NO ALCANZA EL MÁXIMO DE ALQUILADOS 
            //SE AGREGA EL SOPORTE A LA LISTA Y SE MUESTRA INFORMACIÓN AL CLIENTE.
            array_push($this->soportesAlquilados, $soporte);
            echo "<br/><br/><strong>Alquilado soporte a: </strong>" . $this->nombre . "<br>";
            echo "<br/>" . $soporte->muestraResumen();
            $this->numSoportesAlquilados++;
            $soporte->alquilado = true;  //indico que está alquilado
            $alquilerRealizado = true;

        } else if ($this->numSoportesAlquilados >= 3) {
            throw new CupoSuperadoException("Este cliente tiene 3 elementos alquilados. No puede alquilar más en este videoclub hasta que no devuelva algo");
        }
        ;
        // Devuelve el objeto para encadenar
        if ($alquilerRealizado) {
            return $this;  //permite el encadenamiento de métodos si se ha realizado el alquiler
        } else {
            return false;  //si no se ha realizado el alquiler devuelve false
        }

    }

    public function devolver($numero)
    {
        $productoDevuelto = false;
        //VERIFICA QUE LA LISTA ESTÉ VACÍA.
        $listaEmpty = count($this->soportesAlquilados) == 0;
        if ($listaEmpty) {
            echo "<br/>Este cliente no tiene alquilado ningún elemento<br/>";
        } else {
            //COMPRUEBA SI EXISTE ALMACENADO UN SOPORTE CON ESE NÚMERO .
            $existe = self::tieneAlquilado($numero);
            if ($existe) {
                $pos = 0;
                for ($i = 0; $i < count($this->soportesAlquilados); $i++) {
                    //POR CADA ELEMENTO DEL ARRAY COMPARA EL NÚMERO DE SOPORTE CON EL PASADO POR PARÁMETRO.
                    if ($this->soportesAlquilados[$i]->getNumero() === $numero) {
                        //SE GUARDA LA POSICIÓN DEL SOPORTE DENTRO DEL ARRAY DE SOPORTES 
                        $pos = $i;
                        $this->soportesAlquilados[$i]->alquilado = false;
                        $productoDevuelto = true;
                    }
                }
                //SE ELIMINA EL SOPORTE DE LA POSICION $pos
                array_splice($this->soportesAlquilados, $pos, 1);
                //SE DECREMENTA LA CANTIDAD DE SOPORTES ALQUILADOS PARA ESE CLIENTE.
                $this->numSoportesAlquilados--;
                echo "<br/>Se ha devuelto un soporte correctamente<br/>";

            }
            try {
                if (!$existe) {
                    throw new SoporteNoEncontradoException("Soporte no encontrado en la lista de soportes");
                }
            } catch (SoporteNoEncontradoException $e) {
                echo "<br/>" . $e->getMessage() . "<br/>";
            }
        }

        // Devuelve el objeto para encadenar
        if ($productoDevuelto) {
            return $this;  //permite el encadenamiento de métodos si se ha realizado la devolución
        } else {
            return false;  //si no se ha realizado la devuelve false
        }
    }

    public function listaAlquileres()
    {
        $listaEmpty = count($this->soportesAlquilados) == 0;
        //COMPRUEBA SI LA LISTA ESTÁ VACÍA
        if ($listaEmpty) {
            echo "<br/>Este cliente no tiene alquilado ningún elemento<br/>";
        } else {
            echo "<br/> <strong>El cliente tiene " . $this->numSoportesAlquilados . " soportes alquilados</strong><br/><br/>";
            //POR CADA SOPORTE EN LA LISTA DE SOPORTES SE LLAMA AL MÉTODO  muestraResumen().
            foreach ($this->soportesAlquilados as $item) {
                $item->muestraResumen();
            }
        }
    }
}
