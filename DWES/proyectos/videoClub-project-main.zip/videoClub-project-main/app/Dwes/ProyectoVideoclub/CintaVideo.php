<?php
namespace Dwes\ProyectoVideoclub;
include_once "Soporte.php";
use Dwes\ProyectoVideoclub\Soporte;

class CintaVideo extends Soporte
{
    private $duracion;
    public function __construct($titulo, $precio, $duracion)
    {
        parent::__construct($titulo, $precio);
        $this->duracion = $duracion;
    }
    public function muestraResumen()
    {
        echo "Película en VHS:";
        parent::muestraResumenComun();
        echo "<br/> Duracion: " . $this->duracion . " minutos<br/><br/>";

    }
}
?>