<?php
include("../autoload.php");
use Dwes\ProyectoVideoclub\Dvd;
use Dwes\ProyectoVideoclub\Juego;
use Dwes\ProyectoVideoclub\Videoclub;

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soporte</title>
</head>

<body>
    <?php

    //PRUEBA CLASE SOPORTE (CUANDO LA CLASE SOPORTE SE HACE ABSTRACTA NO FUNCIONA ESTA PRIMERA PRUEBA PORQUE NO SE PUEDEN CREAR INSTANCIAS DE LA CLASE SOPORTE)
/*$soporte1 = new Soporte("Tenet", 22, 3); 
echo "<strong>" . $soporte1->titulo . "</strong>"; 
echo "<br>Precio: " . $soporte1->getPrecio() . " euros"; 
echo "<br>Precio IVA incluido: " . $soporte1->getPrecioConIVA() . " euros";
$soporte1->muestraResumen();*/

    //PRUEBA CLASE DVD
/*$miDvd = new Dvd("Origen", 24, 15,"es,en,fr", "16:9"); 
echo "<strong>" . $miDvd->titulo . "</strong>"; 
echo "<br>Precio: " . $miDvd->getPrecio() . " euros"; 
echo "<br>Precio IVA incluido: " . $miDvd->getPrecioConIva() . " euros";
$miDvd->muestraResumen();*/

    //PRUEBA CLASE JUEGO
$miJuego = new Juego("The Last of Us Part II", 26, 49.99, "PS4", 1, 1); 
echo "<strong>" . $miJuego->titulo . "</strong>"; 
echo "<br>Precio: " . $miJuego->getPrecio() . " euros"; 
echo "<br>Precio IVA incluido: " . $miJuego->getPrecioConIva() . " euros";
$miJuego->muestraResumen();

    //PROBAR VIDEOCLUB
     $vc = new Videoclub("Severo 8A");

     //voy a incluir unos cuantos soportes de prueba 
     $vc->incluirJuego("God of War", 19.99, "PS4", 1, 1);
     $vc->incluirJuego("The Last of Us Part II", 49.99, "PS4", 1, 1);
     $vc->incluirDvd("Torrente", 4.5, "es", "16:9");
     $vc->incluirDvd("Origen", 4.5, "es,en,fr", "16:9");
     $vc->incluirDvd("El Imperio Contraataca", 3, "es,en", "16:9");
     $vc->incluirCintaVideo("Los cazafantasmas", 3.5, 107);
     $vc->incluirCintaVideo("El nombre de la Rosa", 1.5, 140);

     //Probando metodos en cadena con control de excepciones.
     $vc->incluirSocio("Amancio Ortega")->alquilarSocioProducto(0, 0)->alquilarSocioProducto(0, 1)->alquilarSocioProducto(0, 2)->alquilarSocioProducto(0, 3);


     //listo los productos 
     $vc->listarProductos();

     //voy a crear algunos socios 
     $vc->incluirSocio("Amancio Ortega");
     $vc->incluirSocio("Pablo Picasso", 2);

     $vc->alquilarSocioProducto(1, 2);
     $vc->alquilarSocioProducto(1, 3);
     //alquilo otra vez el soporte 2 al socio 1. 
 // no debe dejarme porque ya lo tiene alquilado 
     $vc->alquilarSocioProducto(1, 2);
     //alquilo el soporte 6 al socio 1. 
 //no se puede porque el socio 1 tiene 2 alquileres como máximo 
     $vc->alquilarSocioProducto(1, 6);

     //listo los socios 
     $vc->listarSocios();
 


    //******************PROBAR VIDEOCLUB 2.0 PARTES 335,336,337**************************
    

    $vc = new Videoclub("Severo 8A");

    //voy a incluir unos cuantos soportes de prueba 
    $vc->incluirJuego("God of War", 19.99, "PS4", 1, 1);
    $vc->incluirJuego("The Last of Us Part II", 49.99, "PS4", 1, 1);
    $vc->incluirDvd("Torrente", 4.5, "es", "16:9");
    $vc->incluirDvd("Origen", 4.5, "es,en,fr", "16:9");
    $vc->incluirDvd("El Imperio Contraataca", 3, "es,en", "16:9");
    $vc->incluirCintaVideo("Los cazafantasmas", 3.5, 107);
    $vc->incluirCintaVideo("El nombre de la Rosa", 1.5, 140);


    //SUBPRUEBA 1  PUNTO 335
    /*//Probando metodos en cadena con control de excepciones.
    $vc->incluirSocio("Amancio Ortega")->alquilarSocioProducto(0, 0)->alquilarSocioProducto(0, 1)->alquilarSocioProducto(0, 2);
    $vc->incluirSocio("Pedro Vargas")->alquilarSocioProducto(1, 4);


    //listo los productos 
    $vc->listarProductos();
   
    //compruebo número de alquileres del videoclub
    $vc->getNumProductosAlquilados();
    $vc->getNumTotalAlquileres();
     
    //listo los socios 
    $vc->listarSocios();*/


    //SUBPRUEBA 2  PUNTO 336
    
    // probar alquilarSociosProductos (no debe permitir alquilarlo porque el producto 0 ya está alquilado)
    /*$productosaAlquilar=[0,5,6];
    $vc->alquilarSocioProductos(1,$productosaAlquilar);*/


    //SUBPRUEBA 3  PUNTO 336
      $vc->incluirSocio("Amancio Ortega")->alquilarSocioProducto(0, 0)->alquilarSocioProducto(0, 1)->alquilarSocioProducto(0, 2);
      $vc->incluirSocio("Pedro Vargas")->alquilarSocioProducto(1, 4);
       // probar alquilarSociosProductos (debe permitir alquilarlos)
       $productosaAlquilar=[5,6];
       $vc->alquilarSocioProductos(1,$productosaAlquilar);

       //vuelvo a comprobar el número de alquileres del videoclub (debe devolver que se han realizado 6 alquileres)
      $vc->getNumProductosAlquilados();
      $vc->getNumTotalAlquileres();

         //listo los socios 
     $vc->listarSocios();


    //SUBPRUEBA 4   PUNTO 337  devuelvo un producto  totalAlquiler=5 numProductosAlquilados=4 Amancio=2 alquilados Pedro=2 alquilados
    /*$productosaAlquilar=[5,6];
    $vc->incluirSocio("Amancio Ortega")->alquilarSocioProducto(0, 0)->alquilarSocioProducto(0, 1)->alquilarSocioProducto(0, 2)->devolverSocioProducto(0,0);
    $vc->incluirSocio("Pedro Vargas")->alquilarSocioProductos(1,$productosaAlquilar);
    
   
    //vuelvo a comprobar el número de alquileres del videoclub (debe devolver que se han realizado 6 alquileres)
    $vc->getNumProductosAlquilados();
    $vc->getNumTotalAlquileres();

    //listo los socios 
     $vc->listarSocios();*/



    //SUBPRUEBA 5 PUNTO 337  devuelvo un producto no me debe dejar porque no está alquilado
    $productosaAlquilar = [5, 6];
    $vc->incluirSocio("Amancio Ortega")->alquilarSocioProducto(0, 0)->alquilarSocioProducto(0, 1)->alquilarSocioProducto(0, 2)->devolverSocioProducto(0, 4);
    /*$vc->incluirSocio("Pedro Vargas")->alquilarSocioProductos(1,$productosaAlquilar);


    //vuelvo a comprobar el número de alquileres del videoclub (debe devolver que se han realizado 6 alquileres)
    $vc->getNumProductosAlquilados();
    $vc->getNumTotalAlquileres();

    //listo los socios 
    $vc->listarSocios();


    //SUBPRUEBA 6   PUNTO 337  devuelvo VARIOS productos  Amancio=1 alquilado, Pedro= 2 alquilado , NumProductosAlquilados=3,total=5
    /*$productosaAlquilar=[5,6];
    $productosaDevolver=[0,1];
    $vc->incluirSocio("Amancio Ortega")->alquilarSocioProducto(0, 0)->alquilarSocioProducto(0, 1)->alquilarSocioProducto(0, 2)->devolverSocioProductos(0,$productosaDevolver);
    $vc->incluirSocio("Pedro Vargas")->alquilarSocioProductos(1,$productosaAlquilar);


    //vuelvo a comprobar el número de alquileres del videoclub (debe devolver que se han realizado 6 alquileres)
    $vc->getNumProductosAlquilados();
    $vc->getNumTotalAlquileres();

    //listo los socios 
    $vc->listarSocios();*/










    ?>
</body>

</html>